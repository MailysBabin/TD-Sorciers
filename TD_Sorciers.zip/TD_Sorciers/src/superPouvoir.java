public interface superPouvoir {
    int extra = 2;
    double sort();
}
