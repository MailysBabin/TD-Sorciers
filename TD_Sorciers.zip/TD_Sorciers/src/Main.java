public class Main {
    public static void main(String[] args) {

        Personnage tableau[] = new Personnage[3];
        int j = 0;
        String nom[] = {"Balthazar", "Georges"};
        for (int i = 0; i < 2; i++) {
            double v = Math.random() * 100;
            int valeur = (int) v;
            if(j<1){
                tableau[i] = new Sorciers(nom[i], valeur);
            }else {
                tableau[i] = new Monstres(nom[i], valeur);
            }
            j++;
            tableau[i].affichage();
        }
        double v = Math.random() * 100;
        int valeur = (int) v;
        tableau[tableau.length - 1] = new Magiciens("Gandalf", valeur);
        tableau[tableau.length - 1].affichage();
        System.out.println("\n\n");

        for (int ak=0; ak<3;ak++){
            double nu = Math.random() * 3;
            int num = (int) nu;
            int mum;
            do {
                double mu = Math.random() * 3;
                mum = (int) mu;
            }
            while( mum == num);
          tableau[num].attaque(tableau[mum]);
        }
    }


}

