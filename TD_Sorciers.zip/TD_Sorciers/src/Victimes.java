public interface Victimes {
    int subitFrappe(int coup);
    int subitCharme(int coup);
}
