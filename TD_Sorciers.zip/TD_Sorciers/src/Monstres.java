public class Monstres extends Personnage {

    public Monstres(String name, int num) {
        super(name, num);
    }

    public void affichage(){
        System.out.println("Je suis un monstre.");
        super.affichage();
    }

    public int subitCharme(int a) {
        this.addVie(- a);
        System.out.println(this.getNom() + " est charmé, il perd " + a + " points.");
        int retour = this.getVie() / 2;
        return retour;
    }

    public int subitFrappe(int coup){
        this.addVie(- coup);
        System.out.println(this.getNom() + " est frappé, il perd " + coup + " points.");
        int retour = this.getVie() / 2;
        return retour;
    }


    public void attaque(Personnage p) {
        this.affichage();
        p.affichage();
        if (!(this.mort() | p.mort()) ) {
            System.out.println(this.getNom() + " attaque " + p.getNom());
            int coup = this.getVie() / 2;
            int perte = p.subitFrappe(coup);
            if(perte>0) {
                this.addVie(-perte);
                System.out.println(this.getNom() + " perd " + perte + "points.");
            }
            this.affichage();
            p.affichage();
            System.out.println("\n\n");
        }
    }


}
