public abstract class Personnage implements Victimes {

    protected String name;
    protected int pv;


    public Personnage(String a, int num) {
        this.name = a;
        this.pv = num;
    }

    protected void afficherPersonnage() {
        if (this.pv > 0) {
            System.out.println("Je m'appelle " + this.name + " et j'ai " + this.pv + " points de vie.");
        } else {
            System.out.println(this.name + " est mort.");
        }

    }

    public String getNom() {
        return this.name;
    }

    public boolean mort() {
        return this.pv <= 0;
    }

    public int getVie() {
        return this.pv;
    }

    public void addVie(int num) {
        this.pv += num;
    }

    public abstract void attaque(Personnage p);

    public abstract void affichage();

}
