public class Magiciens extends Sorciers implements superPouvoir {

    public Magiciens(String name, int num) {
            super(name, num);
    }

    public void affichage() {
        System.out.println("Je suis un magiciens.");
        this.afficherPersonnage();
    }

    public double sort(){
        return Math.random()*this.getPouvoir();
    }

    public double getPouvoir(){
        return this.pouvoir*extra;
    }

    public int subitCharme(int coup) {
        System.out.println("L'attaque n'a aucun effet.");
        double d = this.sort() * coup;
        int retour = (int) d;
        return -retour;
    }
}
