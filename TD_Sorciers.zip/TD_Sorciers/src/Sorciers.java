public class Sorciers extends Personnage {
    protected double pouvoir;

    public Sorciers(String name, int num) {
        super(name, num);
        pouvoir = Math.random();
    }

    public void affichage() {
        System.out.println("Je suis un sorcier.");
        super.affichage();
    }

    public int subitCharme(int a) {
        System.out.println("L'attaque n'a aucun effet.");
        return 0;
    }

    public double getPouvoir() {
        return pouvoir;
    }

    public void attaque(Personnage p) {
        this.affichage();
        p.affichage();
        if (!(this.mort() | p.mort())) {
            System.out.println(this.getNom() + " attaque " + p.getNom());
            double d = this.getVie() * this.getPouvoir();
            int coup = (int) d;
            int gain = p.subitCharme(coup);
            if (gain > 0) {
                this.addVie(gain);
                System.out.println(this.getNom() + " gagne " + gain + "points.");
            }
            this.affichage();
            p.affichage();
            System.out.println("\n\n");
        }
    }

    public int subitFrappe(int coup) {
        this.addVie(-coup);
        System.out.println(this.getNom() + " est frapppé, il perd " + coup + " points.");
        double d = this.getPouvoir() * this.getVie();
        int retour = (int) d;
        return retour;
    }
}
